from fastapi import FastAPI
from report_service.analyze.routers.youtube_analyze import router as analysis_router
from report_service.audio.routers.audio_service import router as audio_router

app = FastAPI()

app.include_router(analysis_router, prefix="/analysis")
app.include_router(audio_router, prefix="/audio")

@app.get("/")
def root():
    return {"message": "Hello from analyzer_service!"}
